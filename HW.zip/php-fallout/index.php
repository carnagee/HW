<!DOCTYPE html>
<html>
	<head>
		<title>Fallout input</title>
		<link rel="icon" type="text/css" href="img/favicon.png">
		<link rel="stylesheet" href="style.css">
		<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.css" rel="stylesheet">
		<link rel="stylesheet" href="css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<script type="text/javascript" src="js/scripts.js"></script>
	</head>

	<body>
	    <div class="row">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
		<form action="results.php" method="post">
		    <div class="Style">
			<h2>FALLOUT 5</h2>
				<label>Are you a boy or a girl?</label>
				<br>
				<input type=radio name=sex value="Female" class="form-check-input" checked> Girl
				<br>
				<input type=radio name=sex class="form-check-input" value="Male"> Boy
				<br>
				<br>
				<label>What's your name, surname and age</ladel><br><br>
  <div class=row>
    <div class=col-xs-4>
      <input type=text name=name class=form-control placeholder=name>
    </div>
    <div class=col-xs-4>
      <input type=text name=surname class=form-control placeholder=surname>
    </div>
    <div class=col-xs-4>
      <input type=number name=age class=form-control placeholder=age>
    </div>
  </div><br>
        <div class="special">
				<label>S.P.E.C.I.A.L. stats (stat range is 1 - 10; stat sum is 42):</label>
				<br>
				Strength: <input type=number name=strength id="1" value=5  required><br><br>
                Perception: <input type=number name=perception id="2" value=5 required><br><br>
                Endurance: <input type=number name=endurance id="3" value=5 required><br><br>
                Charisma: <input type=number name=charisma id="4" value=5 required><br><br>
                Intelligence: <input type=number name=intelligence id="5" value=5 required><br><br>
                Agility: <input type=number name=agility id="6" value=5 required><br><br>
                Luck: <input type=number name=luck id="7" value=5  required><br><br>
        </div>
				<input type="button" value="Проверить остаток" onclick="addition(this.form)" onclick="is_full()"><br>
				<h4>Остаток очков навыков: <span id='result'>7</span></h4>
				<input type=submit id="submit" disabled value="Confirm"><br><br>
			</div>
			</div>
		</form>
		<div class="I">
		<div class="col-md-4">
		<img onclick="playPause()" src="img/vaultboy.png">
			</div>
		</div>
	</body>
</html>
