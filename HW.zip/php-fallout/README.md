# php-fallout
"index.php" is an input form, you should load it in order to start (it loads automatically). 
"results.php" is an output form, it puts your character info on the screen. 
"vaultboy.jpg" is a background of the input form.
