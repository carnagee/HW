<!DOCTYPE html>
<html>
<head>
	<title>Vault-Tec Chat</title>
	<link rel="icon" type="text/css" href="img/favicon.png">
	<link rel="stylesheet" href="style.css">
	<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
</head>
<body><br><br><br><br>
   <div class=col-xs-2></div>
   <div class=col-xs-2>
       <ul>
       	<li><a href="chat.php"><h4>Chat</h4></a></li>
       	<li><a class="active" href=""><h4>Audio</h4></a></li>
       	<li><a href="options.php"><h4>Options</h4></a></li>
       </ul>
   </div>
   <div class=col-xs-6>
   <div class="Smenu">
   	   <table>
       <tr>
          <td>
            <p>I Don't Want To Set The World On Fire<br/>The Ink Spots</p>
          <audio controls="controls">
            <source src="audio/music/IDWTSAWOF.wav" type="audio/wav">
          </audio>
          </td>
      </tr>
      <tr>
        <td>
          <p>Maybe<br/>The Ink Spots</p>
          <audio controls="controls">
            <source src="audio/music/maybe.mp3" type="audio/mpeg">
          </audio>
        </td>
      </tr>
      <tr>
      <tr>
          <td>
            <p>Way Back Home Bob<br/>Crosby The Bobcats</p>
          <audio controls="controls">
            <source src="audio/music/way_back_home.mp3" type="audio/mpeg">
          </audio>
          </td>
      </tr>
      <tr>
        <td>
          <p>Lets Go Sunning<br/>Jack Shaindlin</p>
          <audio controls="controls">
            <source src="audio/music/lets_go_sunning.mp3" type="audio/mpeg">
          </audio>
        </td>
      </tr>
       <tr>
          <td>
            </audio>
          <p>A Wonderful Guy<br/>Tex Beneke</p>
          <audio controls="controls">
            <source src="audio/music/a_wonderful_guy.mp3" type="audio/mpeg">
          </audio>
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
      <tr>
      <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
       <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
      <tr>
      <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
       <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
      <tr>
      <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
       <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
      <tr>
      <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
      <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
      <tr>
      <tr>
          <td>
            
          </td>
      </tr>
      <tr>
        <td>
          
        </td>
      </tr>
    </table>
   </div>
   <div class=col-xs-2></div>
</body>
</html>