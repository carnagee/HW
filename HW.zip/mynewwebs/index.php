<html>
    <head>
        <title>Tconvert.html</title>
        <link rel="icon" type="text/css" href="img/logo.png">
        <link rel="stylesheet" href="style.css">
        <meta charset=utf-8>
        <meta http-equiv=X-UA-Compatible content=IE=edge>
        <meta name=viewport content=width=device-width, initial-scale=1>
        <link href=css/bootstrap.min.css rel=stylesheet>
        <body>
        <script src=https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js></script>
        <script src=js/bootstrap.min.js></script>
        </head>
        <body>
        <script src=https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js></script>
        <script src=js/bootstrap.min.js></script>
        <script type="text/javascript" src="js/script.js"></script>
    </head>
    <body><br><br><br><br>
        <div class="style">
            <div class="w3-half w3-margin-top">
            <h3>Fahrenheit</h3>
            <input id="inputFahrenheit" class="w3-input w3-border" type="number" min="-459.66999999999996" placeholder="Fahrenheit" oninput="temperatureConverter(this.id,this.value)" onchange="temperatureConverter(this.id,this.value)">
            </div>
            <div class="w3-half w3-margin-top">
            <h3>Celsius</h3>
            <input id="inputCelsius" class="w3-input w3-border" type="number" min="-273.15" placeholder="Celsius" oninput="temperatureConverter(this.id,this.value)" onchange="temperatureConverter(this.id,this.value)">
            </div>
            <div class="w3-half w3-margin-top">
            <h3>Kelvin</h3>
            <input id="inputKelvin" class="w3-input w3-border" type="number" min="0" placeholder="Kelvin" oninput="temperatureConverter(this.id,this.value)" onchange="temperatureConverter(this.id,this.value)">
            </div>
        </div>
    </body>
</html>